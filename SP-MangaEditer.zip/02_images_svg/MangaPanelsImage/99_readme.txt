1.create manga panel image.
2.convert png to svg.
https://new.express.adobe.com/tools/convert-to-svg

