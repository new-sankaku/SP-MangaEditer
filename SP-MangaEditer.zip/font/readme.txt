https://fonts.google.com/specimen/M+PLUS+Rounded+1c
https://fonts.google.com/specimen/Stick?subset=japanese
https://fonts.google.com/specimen/DotGothic16?subset=japanese
https://fonts.google.com/noto/specimen/Noto+Serif+JP?subset=japanese&noto.script=Hira